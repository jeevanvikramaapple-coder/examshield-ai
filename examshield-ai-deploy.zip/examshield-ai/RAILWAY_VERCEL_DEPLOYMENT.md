# ExamShield AI — Railway + Vercel deployment

This repository is prepared for a split deployment: FastAPI + PostgreSQL on Railway, React/Vite on Vercel. Deploying does **not** mean the CCTV/AI inference pipeline is production-ready; see the limitations below.

## 1. Push this project to GitHub

1. Create a **private** GitHub repository named `examshield-ai`.
2. Extract this ZIP and upload the contents of the `examshield-ai` folder (the `backend` and `frontend` folders must be at the repository root).
3. Do not commit `.env`, passwords, JWT secrets, student data, face embeddings, or evidence files.

## 2. Create PostgreSQL on Railway

1. Create a Railway project and add a PostgreSQL database.
2. In the PostgreSQL service, confirm the `DATABASE_URL` variable is available.

## 3. Deploy the backend on Railway

1. Add a service from the GitHub repository.
2. Set its **Root Directory** to `/backend` so Railway builds `backend/Dockerfile`.
3. Add these variables to the backend service:

   - `DATABASE_URL` = reference the PostgreSQL service's `DATABASE_URL` (Railway variable reference).
   - `JWT_SECRET` = generate a long random secret (at least 32 random bytes). Never use `change-me`.
   - `ADMIN_EMAIL` = the admin login email you choose.
   - `ADMIN_PASSWORD` = a unique, strong password.
   - `CORS_ORIGINS` = your Vercel production origin, e.g. `https://examshield-ai.vercel.app` (no trailing slash).
   - `EVIDENCE_DIR` = `/srv/evidence`

4. Add a Railway **Volume** to the backend service and mount it at `/srv/evidence` if evidence files must persist. Without a volume, local container files can be lost on redeploy/restart.
5. Generate a public domain for the backend. The API health check should respond at `https://YOUR-BACKEND-DOMAIN/health` with `{"status":"ok"}`. API docs are at `/docs`; do not leave them publicly exposed in a sensitive production deployment.

## 4. Deploy the frontend on Vercel

1. Import the same GitHub repository into Vercel.
2. Set **Root Directory** to `frontend`. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
3. Add environment variable `VITE_API_URL` = `https://YOUR-BACKEND-DOMAIN` (no trailing slash and no `/api`). Set it for Production, Preview only if you have a matching backend CORS origin.
4. Deploy. Copy the exact production origin (for example `https://examshield-ai.vercel.app`).
5. Update Railway `CORS_ORIGINS` with that exact origin and redeploy the backend.

## 5. Verify before sharing

- Open the Vercel URL; confirm the login page loads.
- Sign in using the `ADMIN_EMAIL` and `ADMIN_PASSWORD` values set on Railway.
- Check Dashboard, Students, and Alerts.
- Check browser developer tools for failed requests/CORS errors.
- Confirm a test record remains after refreshing and after a backend redeploy.
- Confirm evidence upload/write paths are actually persisted on the Railway volume.

## Important limitations and security work

- The README states that no real-hall pilot has run and the inference pipeline is only partially wired/calibrated. Do not claim live AI proctoring is operational.
- Before using real students or exam footage, implement and test consent, retention/deletion, access controls, audit logging, encryption at rest, and a documented human-review process. Face embeddings and exam footage are sensitive personal data.
- Configure backups for Railway PostgreSQL. A persistent volume is not a backup.
- The seeded admin is created only if the configured email does not already exist. Changing `ADMIN_PASSWORD` later will not automatically rotate an existing account's password; implement a secure password-reset/rotation path before production.
- The current backend uses `Base.metadata.create_all`; use Alembic migrations before schema changes in a production environment.
- Do not expose `/docs` or `/openapi.json` publicly for a real deployment unless intentionally protected.
- Check model/library licences before commercial use (YOLOv8/Ultralytics and InsightFace restrictions are noted in the project README).
