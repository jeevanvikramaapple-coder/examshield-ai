from pydantic_settings import BaseSettings
from pydantic import field_validator


class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg2://examshield:examshield@db:5432/examshield"
    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 480
    evidence_dir: str = "/srv/evidence"
    cors_origins: str = "http://localhost:5173,http://localhost:8080"
    admin_email: str = "admin@example.com"
    admin_password: str = "change-me-now"

    @field_validator("database_url", mode="before")
    @classmethod
    def normalize_database_url(cls, value):
        # Railway may expose postgres:// or postgresql://; SQLAlchemy needs a driver.
        if isinstance(value, str):
            if value.startswith("postgres://"):
                return value.replace("postgres://", "postgresql+psycopg2://", 1)
            if value.startswith("postgresql://"):
                return value.replace("postgresql://", "postgresql+psycopg2://", 1)
        return value

    class Config:
        env_file = ".env"


settings = Settings()
