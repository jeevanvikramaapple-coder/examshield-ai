from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select

from .auth import hash_password
from .config import settings
from .db import Base, SessionLocal, engine
from .models import User
from .routers import alerts, auth_routes, students


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if not db.scalar(select(User).where(User.email == settings.admin_email)):
            db.add(User(email=settings.admin_email,
                        password_hash=hash_password(settings.admin_password), role="admin"))
            db.commit()
    yield


app = FastAPI(title="ExamShield AI", version="0.1.0", lifespan=lifespan)
origins = [origin.strip().rstrip("/") for origin in settings.cors_origins.split(",") if origin.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins,
                   allow_methods=["*"], allow_headers=["*"], allow_credentials=False)
app.include_router(auth_routes.router)
app.include_router(students.router)
app.include_router(alerts.router)


@app.get("/health")
def health():
    return {"status": "ok"}
